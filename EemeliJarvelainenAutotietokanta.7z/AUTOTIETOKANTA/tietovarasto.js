'use strict';

const path=require('path');

let DEBUG=false;

const autotiedot = auto =>[
  auto.valmistusNumero, auto.merkki, auto.vuosimalli, auto.arvostelu, auto.rekisterinumero
];

const autotiedotPaivitys = auto =>[
  auto.merkki, auto.vuosimalli, auto.arvostelu, auto.rekisterinumero, +auto.valmistusNumero
];



class Autotietovarasto{
  constructor(varastoija, sqlLauseet){
    this.haeKaikkiAutot=sqlLauseet.haeKaikkiAutot.join(' ');
    this.haeAuto=sqlLauseet.haeAuto.join(' ');
    this.lisaaAuto=sqlLauseet.lisaaAuto.join(' ');
    this.poistaAuto=sqlLauseet.poistaAuto.join(' ');
    this.autodata=varastoija;
    this.paivitaAuto=sqlLauseet.paivitaAuto.join(' ');
  }

  haeKaikki(){
    return new Promise(async(resolve,reject)=>{
      try{
        let tulos= await this.autodata.suoritaKysely(this.haeKaikkiAutot);
        resolve(tulos);
      }
      catch(err){
        reject(kohtalokasVirhe(err));
      }
    });
  }

  hae(valmistusNumero){
    return new Promise(async(resolve, reject)=>{
      try{
        let tulos=  await this.autodata.suoritaKysely(this.haeAuto,+valmistusNumero);
        if(tulos.length===0){
          reject(new Error('Autoa ei löytynyt'));
        }
        else {
          resolve(tulos[0]);
        }
      }
      catch(err){
        reject(kohtalokasVirhe(err));
      }
    });
  }

  lisaa(auto){
    console.log(auto)
    return new Promise(async(resolve, reject)=>{
      try{
        let tulos = await this.autodata.suoritaKysely(this.lisaaAuto,
          ...autotiedot(auto));
        if(tulos.affectedRows===0){
          reject(new Error('Mitään ei lisätty'));

        }
        else{
          resolve(`Auto numerolla ${auto.valmistusNumero} lisättiin`);
        }
      }
      catch(err){
        reject(kohtalokasVirhe(err));
      }
    });
  }

  poista(auto){
    return new Promise(async(resolve, reject)=>{
      try{
        let tulos = await this.autodata.suoritaKysely(this.poistaAuto,
          ...autotiedot(auto));
        if(tulos.affectedRows===0){
          reject(new Error('Mitään ei poistettu'));

        }
        else{
          resolve(`Auto numerolla ${auto.valmistusNumero} poistettiin`);
        }
      }
      catch(err){
        reject(kohtalokasVirhe(err));
      }
    });
  }

  paivita(auto){
    return new Promise(async(resolve,reject)=>{
      try{
        let tulos=await this.autodata.suoritaKysely(this.paivitaAuto,
          ...autotiedotPaivitys(auto));
        if(tulos.sffectedRows===0){
          reject(new Error('Mitään ei muutettu'));
        }
        else{
          resolve(`Auton ${auto.valmistusNumero} tietoja muutettu`);
        }

      }
      catch(err){
        reject(kohtalokasVirhe(err));
      }
    });
  }

} //luokan loppu

module.exports= function alustaTietovarasto(polku, varastoija, debug=false){
  DEBUG=debug;
  const lauseet=require(path.join(polku,'sqlLauseet.json'));
  return new Autotietovarasto(varastoija, lauseet);
};

function kohtalokasVirhe(err){
  return new Error(`Anteeksi, ohjelmamme ei toimi. ${DEBUG?err.message:''}`);
}
