'use strict';
const http=require('http');
const express=require('express');
const path=require('path');

const app=express();
const {host,port,debug}=require('./serverConfig');

const palvelin=http.createServer(app);
const tilakasittelijat=[lahetaVirhesivu, lahetaStatussivu];

const optiot=require('./optiot.json');
const Tietokanta=new require('./tietokanta');
const tietokanta=new Tietokanta(optiot, debug);
const tietovarasto=require('./tietovarasto')(__dirname, tietokanta);

const hakureitit=require('./reitit/hakureitit')(tietovarasto,...tilakasittelijat);
const lisaysreitit=require('./reitit/lisaysreitit')(tietovarasto,...tilakasittelijat);
const paivitysreitit=require('./reitit/paivitysreitit')(tietovarasto,...tilakasittelijat);


app.set('view engine','ejs');
app.set('views', path.join(__dirname, 'omatSivut'));

app.use(express.static(path.join(__dirname,'public')));
app.use(express.urlencoded({extended:false}));

app.get('/', (req,res)=> res.sendFile(path.join(__dirname, 'public','valikko.html')));

app.use('/',hakureitit);
app.use('/',lisaysreitit);
app.use('/',paivitysreitit);
palvelin.listen(port,host,()=>
/*eslint disable no-console*/
  console.log(`palvelin ${host} portissa ${port}`)
);

function lahetaVirhesivu(res,viesti='Virhe',otsikko='virhe'){

  res.render('statussivu',{otsikko, viesti});
}

function lahetaStatussivu(res, viesti='Tilanne',otsikko='Tilanne'){
  res.render('statusSivu',{otsikko, viesti});
}
