'use strict';

const mysql=require('mysql');

module.exports=class Tietokanta{
  constructor(optiot, debug=false) {
    this.optiot=optiot;
    this.debug=debug;
  }

  suoritaKysely(sqlLause, ...parametrit) {
    return new Promise((resolve,reject)=>{
      let yhteys=mysql.createConnection(this.optiot);
      let lause=yhteys.query(sqlLause,[...parametrit],(err,tulos)=>{
        if(err) reject(new Error('SQL virhe: '+err));
        if(this.debug) {
          /*eslint-disable no-console*/
          console.log(lause.sql);
          /*eslint-enable no-console*/
        }

        resolve(tulos);
      });
      yhteys.end();
    });
  }
};
