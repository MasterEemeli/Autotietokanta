'use strict';
const reitit=require('express').Router();

module.exports=(tietovarasto, lahetaVirhesivu,lahetaStatussivu)=>{


  reitit.get('/paivityslomake',(req,res)=>
    res.render('form',
      {otsikko:'Päivitä auton tiedot',
        toiminto:'/paivitaauto',
        vnro:{value:'',readonly:''},
        merkki:{value:'',readonly:'readonly'},
        vmalli:{value:'',readonly:'readonly'},
        arvostelu:{value:'',readonly:'readonly'},
        rnumero:{value:'',readonly:'readonly'},
      })
  );

  reitit.post('/paivitaauto', async (req,res)=>{
    if(!req.body || !req.body.valmistusNumero) return res.sendStatus(500);
    try{
      let auto= await tietovarasto.hae(req.body.valmistusNumero);
      res.render('form',
        {otsikko:'Päivitä auton tiedot',
          toiminto:'/paivitatiedot',
          vnro:{value:auto.valmistusNro,readonly:'readonly'},
          merkki:{value:auto.merkki,readonly:''},
          vmalli:{value:auto.vuosimalli,readonly:''},
          arvostelu:{value:auto.arvostelu,readonly:''},
          rnumero:{value:auto.rekisteriNro,readonly:''},
        });

    }


    catch(err){
      lahetaVirhesivu(res,err.message);
    }
  });

  reitit.post('/paivitatiedot', (req,res)=>{
    if(!req.body)return res.sendStatus(500);
    tietovarasto.paivita(req.body)
      .then(viesti=>lahetaStatussivu(res, viesti))
      .catch(err=>lahetaVirhesivu(res,err.message));
  });


  return reitit;

};
