'use strict';
const reitit=require('express').Router();

module.exports=(tietovarasto, lahetaVirhesivu,lahetaStatussivu)=>{
  let autodata=tietovarasto;

  reitit.get('/lisayslomake',(req,res)=>
    res.render('form',
      {otsikko:'Lisää uusi auto',
        toiminto:'/lisaa',
        vnro:{value:'',readonly:''},
        merkki:{value:'',readonly:''},
        vmalli:{value:'',readonly:''},
        arvostelu:{value:'',readonly:''},
        rnumero:{value:'',readonly:''},
      })
  );

  reitit.post('/lisaa', (req,res)=>{
    if(!req.body) return res.sendStatus(500);
    autodata.lisaa(req.body)
      .then(viesti=>lahetaStatussivu(res,viesti))
      .catch(err=>lahetaVirhesivu(res,err.message));
  });

  reitit.post('/poistaauto', (req,res)=>{
    if(!req.body || !req.body.valmistusNumero) return res.sendStatus(500);
    autodata.poista(req.body)
      .then(viesti=>lahetaStatussivu(res,viesti))
      .catch(err=>lahetaVirhesivu(res,err.message));
  });
  return reitit;

};
