'use strict';

const reitit=require('express').Router();

const alustaReitit=function(tietovarasto, lahetaVirhesivu){
  let autodata=tietovarasto;

  reitit.get('/kaikki', (req,res)=>
    autodata.haeKaikki()
      .then(tulos=> res.render('kaikkiautot', {tulos:tulos}))
      .catch(err=>lahetaVirhesivu(res,err.message))
  );

  reitit.get('/haeauto', (req,res)=>{
    res.render('haeAuto',{otsikko:'Hae',toiminto:'/haeauto'});
  });

  reitit.get('/poistaauto', (req,res)=>{
    res.render('poistaauto',{otsikko:'Hae',toiminto:'/poistaauto'});
  });

  reitit.post('/haeauto', (req,res)=>{

    console.log(req.body);
    if(!req.body || !req.body.valmistusNumero) return res.sendStatus(500);
    let numero=req.body.valmistusNumero;
    autodata.hae(numero)
      .then(auto=>res.render('autoSivu',{auto}))
      .catch(err => lahetaVirhesivu(res,err.message));
  });

  return reitit;
};
module.exports=alustaReitit;
